//
//  DataController.swift
//  AppNoticias
//
//  Created by Admin on 04/10/22.
//

import Foundation
import CoreData

//Classe que vai gerenciar o nosso CoreData

class DataController {
    let persistentContainer: NSPersistentContainer
    
    var viewContext: NSManagedObjectContext {//Criando a propriedade do objeto
        return persistentContainer.viewContext
    }
    
    init(modelName: String) { //inicializando a nossa string e a classe, model name com o nome do nosso datamodel app noticias
        persistentContainer = NSPersistentContainer(name: modelName)//Dando o nome do inicializador
    }
    
    func loadData(completion: (() -> Void)? = nil) {//criando a funcao para carregar o loadData, funcao com o completion
    persistentContainer.loadPersistentStores { storeDescription, error in
        guard error == nil else {
            print("error: \(String(describing: error?.localizedDescription))")
            //Poderiamos usar o alert para poder mostrar para o usuario o erro.
            return
    }
    
    completion?()
}

}

}
