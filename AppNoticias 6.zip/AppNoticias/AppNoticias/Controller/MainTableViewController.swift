//
//  ViewController.swift
//  AppNoticias
//
//  Created by Admin on 10/07/22.
//

import UIKit
import CoreData

class MainTableViewController: UITableViewController { // -> Utilizando esse UI por ser completo e trazendo para nós todos os metodos que já tem em outras UI, tanto a Delegate quanto a DataSource.
    
    //var items: Array = ["EBAC 1", "EBAC 2", "EBAC 3", "EBAC 4", "EBAC 5"] // -> Array conjunto de caracteres
    //newsData.count // -> contando os 4 index com os seus 5 elementos.
    
    var activityView: UIActivityIndicatorView?
    var fetchedResultController: NSFetchedResultsController<NewsData>//Iniciando a instancia
    var newsData = [NewsData]()// Populando a tableview através da codificacao do json
    var dataController: DataController!//recebendo o gerencimento de dados
    
    fileprivate func setUpFetchedResultController() { //funcao especifica desse metodo
        let fetchRequest: NSFetchRequest<NewsData> = NewsData.fetchRequest()//montando a requisicao
        let sortDescriptor = NSSortDescriptor(key: "title", ascending: true)
        
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        fetchedResultController = NSFetchedResultsController(fetchRequest: fetchRequest, managedObjectContext: dataController.viewContext, sectionNameKeyPath: nil, cacheName: "appNoticias ")
        
        fetchedResultController.delegate = self
        
        do {
            try fetchedResultController.performFetch()//requisicao de fetch para o core data
        } catch {
            print("No fetchedResultController")
        }
            
    }
    
    fileprivate func getNewsData() {
        NetworkManager.shared.getNews { [weak self] result  in
            guard let self = self else { return }
            
            switch result {
            case .success(let response):
                self.deleteData()
                for item in response {//instanciando e passando o contexto para o core data
                    let newsData = NewsData(context: self.dataController.viewContext)
                    
                    newsData.url = item.url //atributos do core data
                    newsData.title = item.title
                    newsData.byline = item.byline
                    
                    if let image = item.media.first?.mediaMetadata.last?.url {
                        guard let imageURL = URL(string: image) else { return }
                        guard let imageData = try? Data(contentsOf: imageURL) else { return } //convertendo a nossa image para um objeto data atraves do try?
                        
                        newsData.image = image
                        newsData.data = imageData
                    }
                    try? self.dataController.viewContext.save()//salvando o core data.
                }
                
            case .failure(let error):
                print("error: \(error)")
            }
            
            DispatchQueue.main.async { //se der falha chamamos ele depois para dar um reload na tableview
                self.tableView.reloadData()
                self.hideActivityIndicator()
            }
        }
    }
    
    //configurando a nossa requisicao
    
    fileprivate func deleData() {//Funcao para deletar o conteudo que nos temos
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NewsData.fetchRequest()//montando a requisicao para o core data
        
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        deleteRequest.resultType = .resultTypeObjectIDs //retornando os array deletados.
        
        do {
            let context = dataController.viewContext
            let result = try? context.execute(deleteRequest)
            
            guard let deleteResul = result as? NSBatchDeleteResult,
                  let ids = deleteResul.result as? [NSManagedObjectID] else {
                    return
            }
            
            let changes = [NSDeletedObjectIDsKey: ids]
            NSManagedObjectContext.mergeChanges(fromRemoteContextSave:changes, into:[context])
        } catch {
            print("error: \(error as Any)")
        }
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showActivityIndicator()
        getNewsData()
    }
    
    override func viewWillAppear(_ animated: Bool) {//chamando o setup e buscando os dados no core data
        super.viewWillAppear(animated)
        setUpFetchedResultController()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        fetchedResultController = nil
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fetchedResultController.sections[section].numberOfObjects ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { // -> Utilizando o type casting para saber o tipo de metodo.
        let aNewsData = fetchedResultController.object(at: indexPath)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! NewYorkTableViewCell // realizando o typecasting e dizendo o tipo da cell
        
        cell.title.text = aNewsData.title
        cell.by.text = aNewsData.byline
        if let imageData = aNewsData.data{
            cell.imageNews.image = UIImage(data: imageData)
        }
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let aNewsData = fetchedResultController.object(at: indexPath)
        
        guard let url = aNewsData.url else { return }
        
        if let url = URL(string: url){ // acrescentando url na nossa imagem
            UIApplication.shared.open(url)
        }
    }
    
    func showActivityIndicator() {
        activityView = UIActivityIndicatorView(style: .large)
        guard let activityView = activityView else {
            return
        }
        
        self.view.addSubview(activityView) // addview coloca subview da propria tableview
        
        activityView.translatesAutoresizingMaskIntoConstraints = false //constraints nao aceitam optional por isso colocar fals
        
        NSLayoutConstraint.activate([ // forma manual de se colocar as constraints e ativar as mesmas direto com código.
            activityView.widthAnchor.constraint(equalToConstant: 70),
            activityView.heightAnchor.constraint(equalToConstant: 70),
            activityView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            activityView.centerYAnchor.constraint(equalTo: self.view.centerYAnchor)
        ])
        
        activityView.startAnimating() //startando o UIActivity
        
    }
    
    func hideActivityIndicator() {
        guard let activityView = activityView else {
            return
        }
        
        activityView.stopAnimating()
    }
    
}

extension MainTableViewController: NSFetchedResultsControllerDelegate { //protocols do delegate
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates() //Atualizando a tableview
        
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates() //finalizando o passo e atualizando a tableview
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            if let newIndexPath != nil {
                tableView.insertRows(at: [newIndexPath!], with: .none)
            }
            break
        case .delete:
            if let indexPath = indexPath {
                tableView.deleteRows(at: [indexPath], with: .none)
            }
            break
        case .move, .update:
            break
        }
    }
}
